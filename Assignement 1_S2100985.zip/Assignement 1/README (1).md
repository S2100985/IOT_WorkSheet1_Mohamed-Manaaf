# 21076191_Submission 1

## Name
A simple dice game 

## Description
A dice game where both the buttons and the LED is used, player A and B pushes the buttons A and B respectively, player A rolls the dice first, the dice value gets stored in the variable scoreA, after this the same procedure occurs for player B and the values gets stored in scoreB. Then both variables get compared and the winner gets decided.

## Visuals
![Rolled.gif](./Rolled.gif)
![nextRoll.gif](./nextRoll.gif)
![winDeclared.gif](./winDeclared.gif)

## Installation
No installation is needed for this program as it was created online. The website: python.microbit.org is used for the creation of this program.

## Support
The support required with examples and explanations of functions is displayed in the website mentioned above.

## Project status
The status of the project - completed, there will be no further changes
